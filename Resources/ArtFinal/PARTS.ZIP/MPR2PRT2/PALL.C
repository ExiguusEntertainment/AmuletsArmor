#include <stdio.h>
#include <stdlib.h>
#include <dir.h>
#include <io.h>
#include <dos.h>
#include <memory.h>
#include <conio.h>
#include <string.h>
#include <mem.h>

void Process(struct ffblk *ffblk)
{
    FILE *fp ;
    char *name ;
    int type ;
    char *p2 ;
    int stance ;
    int angle ;
    int numFrames ;
    int num ;
    int frame ;
    int zSort ;
    int part ;
    char command[80] ;

    name = ffblk->ff_name ;
    p2 = name + 3 ;
    if (strncmp(name, "WK", 2) == 0)  {
       p2 = name + 2 ;
       stance = 1 ;
       numFrames = 6 ;
    } else if (strncmp(name, "WLK", 3) == 0)  {
       stance = 1 ;
       numFrames = 6 ;
    } else if (strncmp(name, "RWK", 3) == 0)  {
       stance = 1 ;
       numFrames = 6 ;
    } else if (strncmp(name, "RAT", 3) == 0)  {
       stance = 4 ;
       numFrames = 2 ;
    } else if (strncmp(name, "RDI", 3) == 0)  {
       stance = 3 ;
       numFrames = 4 ;
    } else {
       printf("can't handle %s\n", name) ;
       exit(1) ;
    }

    if (strncmp(p2, "CST", 3) == 0)  {
       part = 1 ;
    } else if (strncmp(p2, "RAR", 3) == 0)  {
       part = 3 ;
    } else if (strncmp(p2, "RAM", 3) == 0)  {
       part = 3 ;
    } else if (strncmp(p2, "RLG", 3) == 0)  {
       part = 5 ;
    } else if (strncmp(p2, "LLG", 3) == 0)  {
       part = 4 ;
    } else if (strncmp(p2, "LAM", 3) == 0)  {
       part = 2 ;
    } else if (strncmp(p2, "HLM", 3) == 0)  {
       part = 0 ;
    } else {
       printf("can't handle %s (of %s)\n", p2, name) ;
       exit(1) ;
    }

    sscanf(p2+3, "%d", &num) ;
    num-- ;
    angle = num / numFrames ;
    frame = num % numFrames ;
    angle++ ;
    if (angle == 8)
        angle = 0 ;

    fp = fopen("re.", "w") ;
    printf("part: %d\nstance: %d\nframe: %d\nangle: %d\n",
        part,
        stance,
        frame,
        angle) ;
    printf("name: %s\n", ffblk->ff_name) ;
    printf("Enter zSort: ") ;
    scanf("%d", &zSort) ;
    fprintf(fp, "%d\n%d\n%d\n%d\n%d\n%d\n",
        zSort,
        part,
        0,
        stance,
        frame,
        angle) ;
    fclose(fp) ;

    sprintf(command, "mpr2prt2 %s <re.", ffblk->ff_name) ;
    system(command) ;
}

void main(void)
{
    struct ffblk ffblk;
    int done;
    int count = 0 ;

    done = findfirst("*.MPR", &ffblk, FA_NORMAL);

    while (!done)  {
        Process(&ffblk) ;
        count++ ;
        done = findnext(&ffblk);
    }

    printf("Processed a total of %d files\n", count) ;
}

