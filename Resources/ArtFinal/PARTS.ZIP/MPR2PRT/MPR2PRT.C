#include <stdio.h>
#include <stdlib.h>
#include <dir.h>
#include <io.h>
#include <dos.h>
#include <memory.h>
#include <conio.h>
#include <string.h>
#include <mem.h>

typedef struct {
    unsigned int zSort ;

    /* extra data: */
    unsigned char type ;
    unsigned int partNum ;
    unsigned char stance ;
    unsigned char frame ;
    unsigned char angle ;
} partInfo ;

partInfo info ;
char workArea[30000] ;
char *p_screen = ((char *)0xA0000000) ;
char palette[768] ;

void savedata(struct ffblk *file)
{
    char filename[80] ;
    char *pos ;
    FILE *fp ;
    char path[80] ;
    char next[80] ;

    strcpy(path, "parts") ;
    mkdir(path) ;
    sprintf(next, "\\%02d", info.type) ;
    strcat(path, next) ;
    mkdir (path) ;
    sprintf(next, "\\%05d", info.partNum) ;
    strcat(path, next) ;
    mkdir(path) ;
    sprintf(next, "\\%02d%02d%01d", info.stance, info.frame, info.angle) ;
    strcat(path, next) ;
    strcpy(filename, path) ;
//    strcpy(filename, file->ff_name) ;
//    pos = strstr(filename, ".") ;
//    strcpy(pos, ".PRT") ;
    printf("Writing out %s\n", filename) ;
    fp = fopen(filename, "wb") ;
    fwrite(&info, sizeof(info), 1, fp) ;
    fwrite(workArea, file->ff_fsize, 1, fp) ;
    fclose(fp) ;
}

void enterdata(void)
{
    printf("zSort (0..10000, 0=back): ") ;
    scanf("%d", &info.zSort) ;
    printf("type (see index, 0=head): ") ;
    scanf("%d", &info.type) ;
    printf("part number (0=standard): ") ;
    scanf("%d", &info.partNum) ;
    printf("stance (0=stance, 3=die): ") ;
    scanf("%d", &info.stance) ;
    printf("frame (0, 1, 2, 3, ....): ") ;
    scanf("%d", &info.frame) ;
    printf("angle (0=front, 6=right): ") ;
    scanf("%d", &info.angle) ;
}

void loadpal(void)
{
    FILE *fp ;
    int i ;

    fp = fopen("PALETTE.DAT", "rb") ;
    if (fp == NULL)  {
        asm {
           mov ax, 3h
           int 10h
        }
        puts("cannot load PALETTE.DAT") ;
        exit(1) ;
    }
    fread(palette, 768, 1, fp) ;
    fclose(fp) ;

    outp(0x3C8, 0) ;
    for (i=0; i<768; i++)
        outp(0x03C9, palette[i]) ;
}

void rline(char *to, char *from, int count)
{
    while (count--)  {
        *to = *from ;
        to += 320 ;
        from++ ;
    }
}

void display(void)
{
    unsigned int offset ;
    unsigned char *p_pos ;
    unsigned char count ;
    unsigned x, y ;

    memset(p_screen, 1, 64000) ;
    p_pos = workArea+4 ;
    do {
        offset = *((unsigned int *)p_pos) ;
        if (offset == 0xFFFF)
            break ;
        x = offset & 63 ;
        y = offset >> 6 ;
        offset = (x*320)+y ;
        p_pos+=2 ;
        count = *p_pos ;
        p_pos++ ;
        rline(p_screen+offset, p_pos, count) ;
        p_pos += count ;
    } while (1==1) ;
}

void Process(struct ffblk *file)
{
    FILE *fp ;

    printf("%s ... ", file->ff_name);
    if (file->ff_fsize >= 30000L)  {
        puts("Too big!") ;
    } else {
        printf("(size: %ld) ", file->ff_fsize) ;
        fp = fopen(file->ff_name, "rb") ;
        if (fp == NULL)  {
            puts("CANNOT OPEN!") ;
        } else {
            fread(workArea, file->ff_fsize, 1, fp) ;
            fclose(fp) ;
            display() ;
            gotoxy(1,15) ;
            printf("FILE> %s\n", file->ff_name);
            enterdata() ;
            savedata(file) ;
            getch() ;
        }
    }
}

void main(void)
{
    struct ffblk ffblk;
    int done;
    int count = 0 ;

    asm {
        mov ax, 13h
        int 10h
    }

    loadpal() ;

    done = findfirst("*.MPR", &ffblk, FA_NORMAL);

    while (!done)  {
        Process(&ffblk) ;
        count++ ;
        done = findnext(&ffblk);
    }

    asm {
        mov ax, 3h
        int 10h
    }

    printf("Processed %d files\n", count) ;
}

